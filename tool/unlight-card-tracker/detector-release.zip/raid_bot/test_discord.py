from raid_bot.notifications.discord import (
    DiscordWebhook,
)


WEBHOOK_URL = (
    "https://discord.com/api/webhooks/1533814548023214091/E_2X1GSw6rFoRyviTHfd1If8FnFITxMFZ3U8-6sokXe4wqUnvOXAyVYoHXNqxCiRWTp8"
)



def main():

    discord = DiscordWebhook(
        WEBHOOK_URL
    )


    success = discord.send(
        """
🌀 Raid List Test

靈龜 🟡🐢
啃食者 🟡🐛☠️
黑死獸 🟡☠️
"""
    )


    print(
        "Success"
        if success
        else
        "Failed"
    )


if __name__ == "__main__":
    main()